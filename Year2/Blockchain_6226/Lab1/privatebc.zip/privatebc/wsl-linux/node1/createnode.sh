./geth --datadir node1 init genesis.json
