./geth --datadir node2 init genesis.json
